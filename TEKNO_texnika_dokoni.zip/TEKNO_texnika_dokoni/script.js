const products = [
  {id:1,name:"Nova X Pro",category:"Smartfon",description:"256 GB • AMOLED • 5G",price:6499000,oldPrice:7299000,badge:"TOP TANLOV",rating:"4.9",image:"https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=700&q=85"},
  {id:2,name:"MacBook Air M3",category:"Noutbuk",description:"13.6″ • 8 GB RAM • 256 GB SSD",price:14999000,oldPrice:15999000,badge:"−6%",rating:"4.8",image:"https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=700&q=85"},
  {id:3,name:"AirBeat Pro",category:"Aksessuar",description:"Simsiz quloqchin • Shovqinni kamaytirish",price:899000,oldPrice:1099000,badge:"−18%",rating:"4.7",image:"https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=700&q=85"},
  {id:4,name:"Pixel One 9",category:"Smartfon",description:"128 GB • OLED • Kuchli kamera",price:5799000,oldPrice:null,badge:"YANGI",rating:"4.8",image:"https://images.unsplash.com/photo-151170 the?auto=format&fit=crop&w=700&q=85"},
  {id:5,name:"ProBook 14",category:"Noutbuk",description:"14″ • 16 GB RAM • 512 GB SSD",price:9999000,oldPrice:10999000,badge:"−9%",rating:"4.9",image:"https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=700&q=85"},
  {id:6,name:"Pulse Watch S",category:"Aksessuar",description:"AMOLED • Sport rejimlari • Suvga chidamli",price:1299000,oldPrice:null,badge:"TREND",rating:"4.6",image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=85"}
];
// Correct the product image URL if a source URL has changed.
products[3].image = "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=700&q=85";

const grid = document.getElementById("productsGrid");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");
const resultsCount = document.getElementById("resultsCount");
const emptyState = document.getElementById("emptyState");
let activeCategory = "Barchasi";
let cart = JSON.parse(localStorage.getItem("teknoCart") || "[]");
let favorites = JSON.parse(localStorage.getItem("teknoFavorites") || "[]");
let toastTimer;

function money(value) {
  return new Intl.NumberFormat("uz-UZ").format(value) + " so‘m";
}
function renderProducts() {
  const query = searchInput.value.trim().toLocaleLowerCase("uz");
  let filtered = products.filter(p => {
    const matchesCategory = activeCategory === "Barchasi" || p.category === activeCategory;
    const matchesQuery = `${p.name} ${p.category} ${p.description}`.toLocaleLowerCase("uz").includes(query);
    return matchesCategory && matchesQuery;
  });
  if (sortSelect.value === "price-low") filtered.sort((a,b)=>a.price-b.price);
  if (sortSelect.value === "price-high") filtered.sort((a,b)=>b.price-a.price);
  if (sortSelect.value === "name") filtered.sort((a,b)=>a.name.localeCompare(b.name));
  resultsCount.textContent = `${filtered.length} ta mahsulot`;
  emptyState.hidden = filtered.length !== 0;
  grid.hidden = filtered.length === 0;
  grid.innerHTML = filtered.map(p => `
    <article class="product-card">
      <div class="product-image">
        <span class="product-badge ${p.badge.includes("%") ? "sale" : ""}">${p.badge}</span>
        <button class="wish-btn ${favorites.includes(p.id) ? "liked" : ""}" data-wish="${p.id}" aria-label="Sevimlilarga qo‘shish">${favorites.includes(p.id) ? "♥" : "♡"}</button>
        <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.style.display='none';this.parentElement.classList.add('image-fallback');this.parentElement.insertAdjacentHTML('beforeend','<span class=&quot;fallback-symbol&quot;>✦</span>')">
      </div>
      <div class="product-info">
        <span class="product-category">${p.category}</span>
        <h3 class="product-title">${p.name}</h3>
        <p class="product-desc">${p.description}</p>
        <div class="rating"><span>★</span> ${p.rating} <span style="color:#a0a6b3">•</span> <span style="color:#a0a6b3">Mijozlar bahosi</span></div>
        <div class="product-bottom"><div class="price-wrap"><strong class="product-price">${money(p.price)}</strong>${p.oldPrice ? `<span class="old-price">${money(p.oldPrice)}</span>` : ""}</div><button class="add-btn" data-add="${p.id}" aria-label="Savatga qo‘shish">+</button></div>
      </div>
    </article>`).join("");
}
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>toast.classList.remove("show"), 2600);
}
function saveCart() {
  localStorage.setItem("teknoCart", JSON.stringify(cart));
  updateCart();
}
function addToCart(id) {
  const existing = cart.find(item=>item.id===id);
  if (existing) existing.qty++;
  else cart.push({id,qty:1});
  saveCart();
  showToast(`${products.find(p=>p.id===id).name} savatga qo‘shildi ✓`);
}
function updateCart() {
  const count = cart.reduce((sum,item)=>sum+item.qty,0);
  document.getElementById("cartCount").textContent = count;
  document.getElementById("drawerCount").textContent = `(${count})`;
  const total = cart.reduce((sum,item)=>sum+products.find(p=>p.id===item.id).price*item.qty,0);
  document.getElementById("cartTotal").textContent = money(total);
  document.getElementById("cartEmpty").style.display = cart.length ? "none" : "flex";
  document.getElementById("cartFooter").style.display = cart.length ? "block" : "none";
  document.getElementById("cartItems").innerHTML = cart.map(item=>{
    const p=products.find(product=>product.id===item.id);
    return `<div class="cart-row"><div class="cart-thumb"><img src="${p.image}" alt="${p.name}"></div><div><h4>${p.name}</h4><div class="cart-price">${money(p.price)}</div><div class="qty-controls"><button data-qty="${p.id}" data-change="-1" aria-label="Kamaytirish">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-change="1" aria-label="Ko‘paytirish">+</button></div></div><button class="remove-item" data-remove="${p.id}" aria-label="O‘chirish">×</button></div>`;
  }).join("");
}
function setCategory(category) {
  activeCategory = category;
  document.querySelectorAll("[data-category]").forEach(b=>b.classList.toggle("active",b.dataset.category===category));
  document.querySelectorAll("[data-filter]").forEach(b=>b.classList.toggle("selected",b.dataset.filter===category));
  renderProducts();
}
function openCart() {
  document.getElementById("cartDrawer").classList.add("open");
  document.getElementById("overlay").classList.add("show");
  document.getElementById("cartDrawer").setAttribute("aria-hidden","false");
  document.body.style.overflow="hidden";
}
function closeCart() {
  document.getElementById("cartDrawer").classList.remove("open");
  document.getElementById("overlay").classList.remove("show");
  document.getElementById("cartDrawer").setAttribute("aria-hidden","true");
  document.body.style.overflow="";
}
grid.addEventListener("click",e=>{
  const add=e.target.closest("[data-add]");
  const wish=e.target.closest("[data-wish]");
  if(add) addToCart(Number(add.dataset.add));
  if(wish){
    const id=Number(wish.dataset.wish);
    favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];
    localStorage.setItem("teknoFavorites",JSON.stringify(favorites));
    renderProducts();
    showToast(favorites.includes(id)?"Sevimlilarga qo‘shildi ♥":"Sevimlilardan olib tashlandi");
  }
});
document.getElementById("cartItems").addEventListener("click",e=>{
  const qty=e.target.closest("[data-qty]");
  const remove=e.target.closest("[data-remove]");
  if(qty){
    const id=Number(qty.dataset.qty), item=cart.find(x=>x.id===id);
    item.qty+=Number(qty.dataset.change);
    if(item.qty<=0) cart=cart.filter(x=>x.id!==id);
    saveCart();
  }
  if(remove){cart=cart.filter(x=>x.id!==Number(remove.dataset.remove));saveCart();}
});
document.querySelectorAll("[data-category]").forEach(b=>b.addEventListener("click",()=>{setCategory(b.dataset.category);document.getElementById("products").scrollIntoView({behavior:"smooth"});}));
document.querySelectorAll("[data-filter]").forEach(b=>b.addEventListener("click",()=>setCategory(b.dataset.filter)));
searchInput.addEventListener("input",renderProducts);
sortSelect.addEventListener("change",renderProducts);
document.getElementById("searchFocus").addEventListener("click",()=>{document.getElementById("products").scrollIntoView({behavior:"smooth"});setTimeout(()=>searchInput.focus(),450);});
document.getElementById("resetSearch").addEventListener("click",()=>{searchInput.value="";sortSelect.value="featured";setCategory("Barchasi");});
document.getElementById("openCart").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
document.getElementById("overlay").addEventListener("click",closeCart);
document.getElementById("continueShopping").addEventListener("click",closeCart);
document.getElementById("checkoutBtn").addEventListener("click",()=>{
  if(!cart.length)return;
  showToast("Buyurtma qabul qilish demo rejimida. Do‘kon egasi bilan bog‘laning.");
});
document.getElementById("newsletterForm").addEventListener("submit",e=>{
  e.preventDefault();
  const email=document.getElementById("emailInput").value.trim();
  if(email){showToast("Rahmat! Obuna bo‘lish so‘rovingiz qabul qilindi.");e.target.reset();}
});
document.getElementById("menuToggle").addEventListener("click",()=>{
  const nav=document.getElementById("mainNav");
  const open=nav.classList.toggle("open");
  document.getElementById("menuToggle").setAttribute("aria-expanded",String(open));
  document.getElementById("menuToggle").textContent=open?"×":"☰";
});
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>{
  document.getElementById("mainNav").classList.remove("open");
  document.getElementById("menuToggle").setAttribute("aria-expanded","false");
  document.getElementById("menuToggle").textContent="☰";
}));
document.addEventListener("keydown",e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();document.getElementById("products").scrollIntoView({behavior:"smooth"});setTimeout(()=>searchInput.focus(),450);}
  if(e.key==="Escape")closeCart();
});
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();
updateCart();